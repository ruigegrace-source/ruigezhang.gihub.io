# Ruige Zhang - Professional Portfolio

## Files
- `index.html` — main portfolio page
- `style.css` — website styling

## How to use
1. Create a GitHub repository named `YOUR-USERNAME.github.io`.
2. Upload `index.html` and `style.css`.
3. In GitHub, open Settings → Pages.
4. Select the main branch as the source.
5. Save and wait for GitHub Pages to publish the site.
6. Open `https://YOUR-USERNAME.github.io`.

## Before submitting
- Replace or update any project descriptions you want to make more specific.
- Test the navigation links.
- Test the site on a phone and computer.
- Confirm the email address is correct.
- Take screenshots of your AI planning and website-generation conversations for the assignment.
